package com.mycustomer.domain;

public class CustomerException extends Exception {
    public CustomerException(String message) {
        super(message);
    }    
}