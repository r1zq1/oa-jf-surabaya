package com.mycustomer.test;

import com.mycustomer.domain.Customer;
import com.mycustomer.domain.CustomerException;
import com.mycustomer.service.CustomerService;
import com.mycustomer.service.CustomerServiceImplDB;
import java.util.logging.Level;
import java.util.logging.Logger;

public class TestCustomerDB2 {
    public static void main(String[] args) {
        try {
            CustomerService service = CustomerServiceImplDB.getInstance();
            service.tambahCustomer(new Customer("213", "Abc", "Bcd"));
        } catch (CustomerException ex) {
            Logger.getLogger(TestCustomerDB2.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}