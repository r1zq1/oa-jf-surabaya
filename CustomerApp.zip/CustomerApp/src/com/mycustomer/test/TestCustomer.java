package com.mycustomer.test;

import com.mycustomer.domain.Customer;
import com.mycustomer.domain.CustomerException;
import com.mycustomer.service.CustomerServiceImplMemory;

public class TestCustomer {
    public static void main(String[] args) {
        CustomerServiceImplMemory model = 
                CustomerServiceImplMemory.getInstance();
        System.out.println("Test mencari customer");
        try {
            Customer c = model.cariCustomer("123");
            System.out.println(c);
            model.cariCustomer("321");
        } catch (CustomerException ce) {
            System.out.println(ce.getMessage());
        }   
        System.out.println("Test menambah customer");
        try {
            model.tambahCustomer(new Customer("123", "AA", "BB"));
        } catch (CustomerException ce) {
            System.out.println(ce.getMessage());
        }   
    }
}