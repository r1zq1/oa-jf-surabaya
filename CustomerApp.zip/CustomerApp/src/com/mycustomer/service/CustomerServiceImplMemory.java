package com.mycustomer.service;

import com.mycustomer.domain.Customer;
import com.mycustomer.domain.CustomerException;
import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;

public class CustomerServiceImplMemory implements CustomerService {
    private List<Customer> customers = new ArrayList<>();
    private final static CustomerServiceImplMemory custService 
            = new CustomerServiceImplMemory();
    public static CustomerServiceImplMemory getInstance(){
        return custService;
    }
    private CustomerServiceImplMemory() {
        customers.add(new Customer("123", "Agung", "Cikarang"));
        customers.add(new Customer("124", "Budi", "Bogor"));
        customers.add(new Customer("125", "Andi", "Banten"));
        customers.add(new Customer("126", "Dimas", "Surabaya"));
        customers.add(new Customer("134", "Dedi", "Purwakarta"));
        customers.add(new Customer("135", "Usman", "Yogyakarta"));
        customers.add(new Customer("145", "Irwan", "Medan"));
        customers.add(new Customer("146", "Amir", "Padang"));
        customers.add(new Customer("157", "Marman", "Jakarta"));
        customers.add(new Customer("158", "Nandang", "Bandung"));
    }
    @Override
    public void tambahCustomer(Customer c) throws CustomerException {
        Customer cust = null;
        try {
            cust = cariCustomer(c.getCustomerId());
        } catch (CustomerException e) {
            customers.add(c);
        }        
        if(cust != null) {
            throw new CustomerException("Duplikasi Customer " + c.getCustomerId());
        }
    }
    @Override
    public Customer cariCustomer(String custId) throws CustomerException {
        try {
            return customers.stream().
                filter((cust) -> cust.getCustomerId().equals(custId)).findFirst().get();            
        } catch (NoSuchElementException e) {
            throw new CustomerException("Customer "+custId+" tidak ditemukan");            
        }
    }
    @Override
    public List<Customer> getAllCustomers() throws CustomerException {
        return customers;
    }
    @Override
    public void hapusCustomer(String custId) throws CustomerException {
        try {
            Customer cust = cariCustomer(custId);
            customers.remove(cust);
        } catch (CustomerException e) {
            throw new CustomerException("Customer "+custId+" tidak ditemukan");    
        }                        
    }
    @Override
    public void updateCustomer(Customer c) throws CustomerException {
        try {
            Customer cust = cariCustomer(c.getCustomerId());
            cust.setCustomerAddress(c.getCustomerAddress());
            cust.setCustomerName(c.getCustomerName());
        } catch (CustomerException e) {
            throw new CustomerException("Customer "+c.getCustomerId()+" tidak ditemukan");    
        }                
    }
}