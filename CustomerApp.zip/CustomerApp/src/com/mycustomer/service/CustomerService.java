package com.mycustomer.service;

import com.mycustomer.domain.Customer;
import com.mycustomer.domain.CustomerException;
import java.util.List;

public interface CustomerService {
    void tambahCustomer(Customer c) throws CustomerException;
    Customer cariCustomer(String custId) throws CustomerException;
    List<Customer> getAllCustomers() throws CustomerException;
    void hapusCustomer(String custId) throws CustomerException;
    void updateCustomer(Customer c) throws CustomerException;
}