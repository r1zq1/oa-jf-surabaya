package com.mycustomer.service;

import com.mycustomer.domain.Customer;
import com.mycustomer.domain.CustomerException;
import com.mycustomer.gui.CustomerUI;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class CustomerServiceImplDB implements CustomerService {
    private final String driver = "org.apache.derby.jdbc.ClientDriver";
    private final String url = "jdbc:derby://localhost:1527/CustomerDB";
    private final String username = "netbeans";
    private final String password = "netbeans";
    private static final CustomerServiceImplDB instance = new CustomerServiceImplDB();
    public static CustomerServiceImplDB getInstance(){
        return instance;
    }
    private CustomerServiceImplDB(){ 
        try {
            Class.forName(driver);
        } catch (ClassNotFoundException ex) {
            System.out.println(ex.getMessage());
        }        
    }
    @Override
    public void tambahCustomer(Customer c) throws CustomerException {
        Customer cust = null;
        try {
            cust = cariCustomer(c.getCustomerId());
        } catch (CustomerException e) {
            String query = "INSERT INTO CUSTOMER VALUES ('"
                    + c.getCustomerId() + "', '" + c.getCustomerName()
                    + "', '"+c.getCustomerAddress() + "')";
            try(
                    Connection conn = DriverManager.getConnection(url, username, password);
                    Statement st = conn.createStatement();
            ) {
                    int res = st.executeUpdate(query);
                    CustomerUI.logger.info("Add Customer Sukses");
            } catch (SQLException sqle) {
                throw new CustomerException(sqle.getMessage());
            }
        }        
        if(cust != null) {
            throw new CustomerException("Duplikasi Customer " + c.getCustomerId());
        }
    }
    @Override
    public Customer cariCustomer(String custId) throws CustomerException {
        String query = "Select * From Customer Where customerid = '"+custId+"'";
        Customer c = null;
        try(
                Connection conn = DriverManager.getConnection(url, username, password);
                Statement st = conn.createStatement();
                ResultSet rs = st.executeQuery(query);
         ) {
            while (rs.next()) {
                String cid = rs.getString("CUSTOMERID");
                String name = rs.getString("CUSTOMERNAME");
                String address = rs.getString("ADDRESS");
                c = new Customer(cid, name, address);
            }
            if(c != null) {
                return c;
            } else {
                throw new CustomerException("Customer "+custId+" tidak ditemukan");
            }
        } catch (SQLException ex) {
            throw new CustomerException(ex.getMessage());
        }        
    }
    @Override
    public List<Customer> getAllCustomers() throws CustomerException {
        List<Customer> customers = new ArrayList<>();
        String query = "Select * From Customer";
        try(
                Connection conn = DriverManager.getConnection(url, username, password);
                Statement st = conn.createStatement();
                ResultSet rs = st.executeQuery(query);
         ) {
            while (rs.next()) {
                String cid = rs.getString("CUSTOMERID");
                String name = rs.getString("CUSTOMERNAME");
                String address = rs.getString("ADDRESS");
                customers.add(new Customer(cid, name, address));
            }
            return customers;
        } catch (SQLException ex) {
            throw new CustomerException(ex.getMessage());
        }
    }
    @Override
    public void hapusCustomer(String custId) throws CustomerException {
        Customer c = cariCustomer(custId);
        if(c != null) {
            String query = "Delete From customer Where customerid = '"+custId+"'";
            try(
                    Connection conn = DriverManager.getConnection(url, username, password);
                    Statement st = conn.createStatement();
            ) {
                    int res = st.executeUpdate(query);
            } catch (SQLException sqle) {
                throw new CustomerException(sqle.getMessage());
            }
        } else {
            throw new CustomerException("Customer "+custId+" tidak ditemukan");
        }
    }
    @Override
    public void updateCustomer(Customer c) throws CustomerException {
        Customer cust = cariCustomer(c.getCustomerId());
        if(cust != null) {
            String query = "Update Customer "
                    + "Set customername = '"+c.getCustomerName()+"' , "
                    + "address = '"+c.getCustomerAddress()+"' "
                    + "Where customerid = '"+c.getCustomerId()+"'";
            try(
                    Connection conn = DriverManager.getConnection(url, username, password);
                    Statement st = conn.createStatement();
            ) {
                    int res = st.executeUpdate(query);
            } catch (SQLException sqle) {
                throw new CustomerException(sqle.getMessage());
            }            
        } else {
            throw new CustomerException("Customer "+c.getCustomerId()+" tidak ditemukan");
        }
    }
}